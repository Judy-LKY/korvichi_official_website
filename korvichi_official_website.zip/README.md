# Korvichi Official Website

This is a static company website for Korvichi.

## How to publish on GitHub Pages
1. Upload all files in this folder to your GitHub repository.
2. Go to Repository Settings > Pages.
3. Choose branch: main, folder: root.
4. Add custom domain: www.korvichi.com.
5. In your domain DNS, add a CNAME record: www -> YOUR-GITHUB-USERNAME.github.io.
6. Wait for DNS to update, then enable HTTPS.

## Important
Make sure `index.html` is in the root of the repository, not inside another folder.
